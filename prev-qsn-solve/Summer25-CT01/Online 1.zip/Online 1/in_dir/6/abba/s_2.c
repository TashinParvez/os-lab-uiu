#include<stdio.h>

int main(){
    /* corona */
    printf("Hello World\n");
    return 0;
}